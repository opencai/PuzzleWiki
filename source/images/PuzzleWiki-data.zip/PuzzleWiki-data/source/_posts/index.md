---
title: 欢迎来到谜题百科
date: 2017-04-15 20:00

---

谜题百科致力于搜集世界谜题联合会（World Puzzle Federation）所定义的逻辑谜题，并且通过这个平台向所有喜欢推理的朋友们介绍各式各样有趣的谜题。

目前国外已有一些网站开设了谜题百科（Puzzle Wiki）的版块或是原创谜题的展示页，如以下这些：

* http://wiki.logic-masters.de/
* http://www.janko.at/Raetsel/index.htm
* http://inabapuzzle.com/